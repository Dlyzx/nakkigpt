const apiKey = "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"; // ← Ganti dengan API key kamu
const chatBox = document.getElementById("chat-box");
const form = document.getElementById("chat-form");
const userInput = document.getElementById("user-input");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const message = userInput.value.trim();
  if (message === "") return;

  appendMessage("user", message);
  userInput.value = "";

  const response = await getGPTResponse(message);
  appendMessage("bot", response);
});

function appendMessage(sender, message) {
  const messageDiv = document.createElement("div");
  messageDiv.classList.add(sender === "user" ? "user-message" : "bot-message");
  messageDiv.textContent = message;
  chatBox.appendChild(messageDiv);
  chatBox.scrollTop = chatBox.scrollHeight;
}

async function getGPTResponse(prompt) {
  const endpoint = "https://api.openai.com/v1/chat/completions";

  const headers = {
    "Content-Type": "application/json",
    Authorization: `Bearer ${apiKey}`
  };

  const body = {
    model: "gpt-3.5-turbo",
    messages: [{ role: "user", content: prompt }],
    max_tokens: 100
  };

  try {
    const res = await fetch(endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify(body)
    });

    const data = await res.json();
    return data.choices?.[0]?.message?.content || "Tidak ada respon.";
  } catch (error) {
    return "Terjadi kesalahan saat menghubungi API.";
  }
}
